# CHANGELOG.md

## [2.0.0] - 2024-08-28

- Redesign the entire template

## [1.3.0] - 2024-07-05

- Replace Contentlayer with MDX

## [1.2.0] - 2023-12-07

- Update Next.js to 14

## [1.1.2] - 2023-10-04

- Update Twitter icon
- Update dependencies

## [1.1.0] - 2023-05-06

- Update dependencies
- Improve modal video component

## [1.0.0] - 2023-04-11

First release
